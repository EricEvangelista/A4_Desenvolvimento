<?php
	include_once dirname(__DIR__).'/model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	$manager = new Manager();
	$data = $manager->select_common('tb_product',null,null," WHERE product_name LIKE '%".$_POST['filter']."%'");
	if($data){
		echo json_encode($data);
	}else{
		echo json_encode("nenhum produto encontrado...");
	}