<?php 
	include_once dirname(__DIR__).'/model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	session_start();
	$manager = new Manager();

	if(isset($_POST)){
		// dados do produto
		$data_product = $manager->select_common('tb_product',null,array('product_barcode' => $_POST['barcode']),null);
		if($data_product){

			if($_POST['quantity'] == ""){
				$quantity = 1;
				$value_final = $quantity * $data_product[0]['product_value'];
			}else{
				$quantity = $_POST['quantity'];
				$value_final = $quantity * $data_product[0]['product_value'];
			}

			$return['barcode'] = $data_product[0]['product_barcode'];
			$return['product_id'] = $data_product[0]['product_id'];
			$return['product_name'] = $data_product[0]['product_name'];
			$return['product_value_unique'] = $data_product[0]['product_value'];
			$return['product_value'] = $value_final;
			$return['product_quantity'] = $quantity;
			$return['product_image'] = $data_product[0]['product_image'];

			if(!isset($_SESSION['shopping_cart'])){
				$new_sale = $manager->insert_common('tb_sale',array('sale_vendor' => $_SESSION['user']['user_id'], 'sale_box' => $_SESSION['user']['user_box'], 'sale_status' => 0),null);
				$new_data = $manager->insert_common('tb_data_sale',array('datasale_sale' => $new_sale, 'datasale_product' => $return['product_id'], 'datasale_value' => $return['product_value'], 'datasale_quantity' => $return['product_quantity']),null);

				$return['sale'] = $new_sale;

				$_SESSION['shopping_cart'][0] = $return;

			}else{
				$new_data = $manager->insert_common('tb_data_sale',array('datasale_sale' => $_SESSION['shopping_cart'][0]['sale'], 'datasale_product' => $return['product_id'], 'datasale_value' => $return['product_value'], 'datasale_quantity' => $return['product_quantity']),null);
				$return['sale'] = $_SESSION['shopping_cart'][0]['sale'];
				array_push($_SESSION['shopping_cart'], $return);
			}

			echo json_encode($return);
		}
	}
	
?>