<?php
	include_once dirname(__DIR__).'/model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';
	include_once $url['path'].'/model/class/User.class.php';

	$manager = new Manager();
	$user = new User();

	if(isset($_GET['method']) and $_GET['method'] == "login"){
		if(isset($_POST)){
			// verifica se existe o determinado usuário
			$log = $manager->select_common('tb_user',null,array('user_login' => $_POST['user_login'], 'user_password' => md5($_POST['user_password']))," LIMIT 1");
			if($log){

				// verifica se o usuário possui caixa
				$vc = $manager->select_common('tb_box',null,array('box_user' => $log[0]['user_id']),null);
				if($vc){
					$nd = array('user_box' => $vc[0]['box_id']);
					$update_box = $manager->update_common('tb_box',array('box_status' => 1),array('box_id' => $vc[0]['box_id']),null);
					
					$data = array_merge($log[0],$nd);

					session_start();
					$_SESSION['user'] = $data;
					header('location: '.$url['index']);

				}else{
					header('location: '.$url['index'].'/login.php?Usuário não possui caixa');
				}

			}else{
				header('location: '.$url['index'].'/login.php?failed=Chave de acesso invalida,favor conferir login e senha novamente.');
			}

		}else{
			header('location: '.$url['index']);
		}

	}elseif(isset($_GET['method']) and $_GET['method'] == "logout"){
		session_start();
		$manager->update_common('tb_box',array('box_status' => 0),array('box_id' => $_SESSION['user']['user_box']),null);
		session_destroy();
		header('location: '.$url['index'].'/login.php');
	}else{
		header('location: '.$url['index']);
	}