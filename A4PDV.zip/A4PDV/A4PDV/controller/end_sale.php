<?php
	include_once dirname(__DIR__).'/model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	$manager = new Manager();
	session_start();
	if(isset($_POST)){

		// montando o array de atualização de dados de venda no banco
		$update_data = array(
				'sale_value' => number_format($_POST['value'],2),
				'sale_change' => number_format($_POST['value_change'],2),
				'sale_percent' => number_format($_POST['value_percent'],2),
				'sale_payment' => $_POST['type_payment'],
			);

		$sale_finish = $manager->update_common('tb_sale',$update_data,array('sale_id' => $_SESSION['shopping_cart'][0]['sale']),null);
		unset($_SESSION['shopping_cart']);
		header('location: '.$url['index']);
	}else{
		header('location: '.$url['index'].'/?failed=houve um erro na finalização da compra modafoca');
	}