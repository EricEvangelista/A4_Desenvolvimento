<?php
	include_once dirname(__DIR__).'/model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	session_start();
	$manager = new Manager();

	$data_value = $manager->select_common('tb_data_sale',null,array('datasale_sale' => $_SESSION['shopping_cart'][0]['sale']),null);
	if($data_value){
		$v = 0;
		foreach ($data_value as $key => $value) {
			$v = $v + ($value['datasale_value'] * $value['datasale_quantity']);
		}

		echo json_encode($v);
	}