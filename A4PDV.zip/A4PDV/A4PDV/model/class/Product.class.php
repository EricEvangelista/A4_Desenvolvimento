<?php
	class Product {
		private $data = array();

		public function __construct() {

		}

		public function __set($name,$values){
			$this->name = $values;
		}

		public function __get($name){
			return $this->name;
		}
	}
