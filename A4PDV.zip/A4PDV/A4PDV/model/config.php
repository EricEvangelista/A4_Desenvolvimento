<?php
	// path e index
	$project = "in9PDV";
	$url = array();
	$url['path'] = $_SERVER['DOCUMENT_ROOT'].'/'.$project;
	$url['index'] = 'http://'.$_SERVER['SERVER_NAME'].'/'.$project;

	// configurãção de data
	date_default_timezone_set('America/Fortaleza');

	ini_set('display_errors',1);
	ini_set('display_startup_erros',1);
	error_reporting(E_ALL);
