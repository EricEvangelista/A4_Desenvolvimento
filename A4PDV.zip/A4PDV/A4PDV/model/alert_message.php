<?php
	if(isset($_GET['success']) and !empty($_GET['success'])){
		echo '<div id="alert_system" style="position: fixed; z-index: 9999;" class="alert alert-success" role="alert">
			  <span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span>
			  <span class="sr-only">Falha:</span>
			  '.$_GET['success'].'
			</div>';
	}elseif(isset($_GET['failed']) and !empty($_GET['failed'])){
		echo '<div id="alert_system" style="position: fixed; z-index: 9999;" class="alert alert-danger" role="alert">
			  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
			  <span class="sr-only">Falha:</span>
			  '.$_GET['failed'].'
			</div>';
	}