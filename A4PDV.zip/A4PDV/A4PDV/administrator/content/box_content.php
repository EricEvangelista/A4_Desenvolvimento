<?php
	require_once '../../model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';
	$manager = new Manager();
	$data_box = $manager->select_common('tb_box',null,null,null);
	if($data_box){

	echo '<table class="table table-bordered table-responsive table_two">
			<thead>
				<tr>
					<th>#</th>
					<th>Caixa</th>
					<th>Operador</th>
					<th>Status</th>
					<th>#</th>
				</tr>
			</thead>
			<tbody>';

			foreach ($data_box as $key => $value) {

				if($value['box_status'] == 0){
					$status = '<span class="label label-warning"><i class="fa fa-close"></i> Fechado</span>';
					$access = "enabled";
				}elseif($value['box_status'] == 1){
					$status = '<span class="label label-success"><i class="fa fa-cog fa-spin"></i> Em Operação</span>';
					$access = "disabled";
				}

				if($value['box_user'] == 0){
					$box_user = '<button class="btn btn-default btn-sm" title="Definir Operador" data-toggle="modal" data-target="#operador-caixa-'.$value['box_id'].'"><i class="fa fa-plus"></i> <i class="fa fa-user"></i> Inserir Operador</button>';
				}else{
					$data_box_user = $manager->select_common('tb_user',null,array('user_id' => $value['box_user']),null);
					if($data_box_user){
						$box_user = '<div class="pull-left"> <img src="'.$data_box_user[0]['user_picture'].'" class="img-circle img-responsive" width="30" height="30" /> </div> <h5 class="text-center"><b>'.$data_box_user[0]['user_name']." ".$data_box_user[0]['user_lastname']."</b></h5>";
					}else{
						$box_user = "<p class='text-danger'><i class='fa fa-ban'></i> Usuário Inexistente</p>";
					}
				}

				echo '<tr>';
				echo '<td><i class="fa fa-desktop fa-2x" aria-hidden="true"></i></td>';
				echo '<td>'.$value['box_id'].'</td>';
				echo '<td>'.$box_user.'</td>';
				echo '<td>'.$status.'</td>';
				echo '<td>
						<button class="btn btn-danger btn-sm" title="Deletar Caixa" data-toggle="modal" data-target="#deletar-caixa-'.$value['box_id'].'" '.$access.'><i class="fa fa-trash"></i></button>
						<button class="btn btn-warning btn-sm" title="Esvaziar Caixa" data-toggle="modal" data-target="#esvaziar-caixa-'.$value['box_id'].'" '.$access.'><i class="fa fa-flag"></i></button>
					  </td>';

				echo '</tr>';

					// modal de deletar caixa
					echo '<div class="modal fade bs-example-modal-sm" id="deletar-caixa-'.$value['box_id'].'" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
						  <div class="modal-dialog modal-sm" role="document">
						    <div class="modal-content">
						       <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h4 class="modal-title" id="myModalLabel">Deletar Caixa</h4>
							      </div>
							      <div class="modal-body">
							        <p>Você tem certeza que deseja deletar o caixa '.$value['box_id'].'?</p>
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
							        <a href="'.$url['index'].'/administrator/engine/box.php?action=delete&box='.$value['box_id'].'" value="'.$value['box_id'].'" class="btn btn-danger">Sim,Deletar Caixa '.$value['box_id'].'</a>
							      </div>
						    </div>
						  </div>
						</div>';

					// modal de esvaziar caixa
					echo '<div class="modal fade bs-example-modal-sm" id="esvaziar-caixa-'.$value['box_id'].'" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
						  <div class="modal-dialog modal-sm" role="document">
						    <div class="modal-content">
						       <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h4 class="modal-title" id="myModalLabel">Esvaziar Caixa</h4>
							      </div>
							      <div class="modal-body">
							        <p>Você tem certeza que deseja esvaziar o caixa '.$value['box_id'].'?</p>
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
							        <a href="'.$url['index'].'/administrator/engine/box.php?box='.$value['box_id'].'&action=void" value="'.$value['box_id'].'" class="btn btn-warning">Sim,Esvaziar Caixa '.$value['box_id'].'</a>
							      </div>
						    </div>
						  </div>
						</div>';


					// modal de inserir um operador ao caixa
					echo '<div class="modal fade bs-example-modal-sm" id="operador-caixa-'.$value['box_id'].'" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
						  <div class="modal-dialog modal-sm" role="document">
						    <div class="modal-content">
						       <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h4 class="modal-title" id="myModalLabel">Inserir Operador</h4>
							      </div>
							      <div class="modal-body">';

							      	$data_operador = $manager->select_common('tb_user',null,array('user_type_user' => 'Operador'),null);
							      	if($data_operador){

							      		echo '<div class="list-group">';

							      		foreach ($data_operador as $k => $v) {
							      			echo '<a href="'.$url['index'].'/administrator/engine/box.php?action=operary&operary='.$v['user_id'].'&box='.$value['box_id'].'" class="list-group-item">';
							      			echo '<div class="row">';
							      			echo '<div class="col-md-4">';
							      			echo '<img src="'.$v['user_picture'].'" class="img-responsive img-circle" width="30" height="30" />';
							      			echo '</div>';
							      			echo '<div class="col-md-8">';
							      			echo $v['user_name']." ".$v['user_lastname'];
							      			echo '</div>';
							      			echo '</div>';
							      			echo '</a>';
							      		}

							      		echo '</div>';

							      	}else{
							      		echo 'Nenhum Usuário Operador Disponivel';
							      	}

							  echo '</div>
							      <div class="modal-footer">
							       
							      </div>
						    </div>
						  </div>
						</div>';
			}
				
			echo '</tbody>
			</table>';
	}else{
		echo '<div class="alert alert-warning" role="alert">
                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                <span class="sr-only">Vazio:</span>
                Nenhum caixa registrado no sistema...
              </div>';
	}
?>