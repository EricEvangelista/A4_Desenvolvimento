<?php
	include_once '../../model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	$manager = new Manager();

	if(isset($_GET['action'])){
		switch ($_GET['action']) {
			case 'insert':
					if(isset($_POST)){

						if($manager->insert_common('tb_product',$_POST,null)){
							header('location: '.$url['index'].'/administrator/?success=Produto cadastrado com sucesso');
						}else{
							header('location: '.$url['index'].'/administrator/?success=Falha no cadastro do produto');
						}

					}else{
						header('location: '.$url['index'].'/administrator');
					}
				break;

			case 'update':
					if(isset($_POST)){
						$id = $_POST['product_id'];
						unset($_POST['product_id']);
						
						if($manager->update_common('tb_product',$_POST,array('product_id' => $id),null)){
							header('location: '.$url['index'].'/administrator/?page=database&success=dados atualizados com sucesso');
						}else{
							header('location: '.$url['index'].'/administrator/?page=database&failed=erro na atualização dos dados..');
						}
					}else{
						header('location: '.$url['index'].'/administrator');
					}

				break;
			
			default:
				# code...
				break;
		}
	}else{
		header('location: '.$url['index'].'/administrator');
	}
