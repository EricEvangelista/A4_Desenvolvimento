<?php
	switch (@$_GET['page']) {
		case 'database':
			include_once $url['path'].'/administrator/content/database.html';
			break;

		case "box":
			include_once $url['path'].'/administrator/content/box.html';
			break;
		
		default:
			include_once $url['path'].'/administrator/content/home.html';
			break;
	}