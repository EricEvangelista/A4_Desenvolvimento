<?php
	include_once '../../model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	$manager = new Manager();

	if(isset($_GET['action'])){
		switch ($_GET['action']) {
			case 'insert':
					if(isset($_POST)){
						// verifica se usuário ja existe
						if($manager->select_common('tb_user',null,array('user_cpf' => $_POST['user_cpf']),null)){
							header('location: '.$url['index'].'/administrator/?failed=usuário ja existente no sistema');
						}else{
							// caso o contrario,prossegue o cadastro

							// criptografa a senha
							$pass = md5($_POST['user_password']);
							unset($_POST['user_password']);
							$new_data = array('user_password' => $pass);
							$data = array_merge($new_data, $_POST);

							if($manager->insert_common('tb_user',$data," LIMIT 1")){
								header('location: '.$url['index'].'/administrator/?success=usuario cadastrado com sucesso');
							}else{
								header('location: '.$url['index'].'/administrator/?failed=falha no cadastro do usuario');
							}
						}
					}
				break;
			
			default:
				header('location: '.$url['index'].'/administrator/');
				break;
		}
	}else{
		header('location: '.$url['index'].'/administrator');
	}