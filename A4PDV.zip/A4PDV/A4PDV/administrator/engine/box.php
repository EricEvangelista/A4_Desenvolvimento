<?php
	include_once '../../model/config.php';
	include_once $url['path'].'/model/class/Connect.class.php';
	include_once $url['path'].'/model/class/Manager.class.php';

	$manager = new Manager();

	if(isset($_GET['action'])){
		switch ($_GET['action']) {
			case 'delete':

					if(isset($_GET['box'])){
						if($manager->delete_common('tb_box',array('box_id' => $_GET['box']),null)){
							header('location: '.$url['index'].'/administrator/?page=box&success=Caixa deletado com sucesso');
						}else{
							header('location: '.$url['index'].'/administrator/?page=box&failed=Não foi possivel deletar o caixa');
						}
					}else{
						header('location: '.$url['index'].'/?page=box');
					}

				break;

			case 'operary':

					if(isset($_GET['operary'])){
						
						if($manager->select_common('tb_box',null,array('box_user' => $_GET['operary']),null)){

							header('location: '.$url['index'].'/?page=box&failed=Usuário ja assumiu um caixa no sistema.');

						}else{


							if($manager->update_common('tb_box',array('box_user' => $_GET['operary']),array('box_id' => $_GET['box']),null)){
								header('location: '.$url['index'].'/administrator/?page=box&success=Operario definido com sucesso');
							}else{
								header('location: '.$url['index'].'/?page=box');
							}

						}
					}

				break;

			case 'void':

					if($manager->update_common('tb_box',array('box_user' => ''),array('box_id' => $_GET['box']),null)){
						header('location: '.$url['index'].'/administrator/?page=box&success=Caixa Esvaziado com sucesso');
					}else{
						header('location: '.$url['index'].'/administrator/?page=box&failed=falha na ação de caixa');
					}

				break;

			case 'format':
			
					if($manager->format('tb_box')){
						header('location: '.$url['index'].'/administrator/?page=box&success=formatação concluida!');
					}else{
						header('location: '.$url['index'].'/administrator/?page=box&failed=falha na formatação!');
					}

				break;

			
			default:
				return false;
				break;
		}
	}else{

		if(isset($_POST) and isset($_POST['box_insert']) and $_POST['box_insert'] == 1){
			unset($_POST['box_insert']);
			$manager->insert_common('tb_box',$_POST,null);
		}
	}