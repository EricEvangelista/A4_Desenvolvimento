<!DOCTYPE html>
<html>
	<head>
	<?php include_once $url['path'].'/view/content/css.html'; ?>
	</head>

	<body>

			<div class="row">
				<div class="col-xs-2 col-sm-3 col-md-4 col-lg-4"></div>
				<div class="col-xs-8 col-sm-6 col-md-4 col-lg-4">
					<div class="jumbotron">
						login
					</div>
				</div>
				<div class="col-xs-2 col-sm-3 col-md-4 col-lg-4"></div>
			</div>
	</body>
</html>