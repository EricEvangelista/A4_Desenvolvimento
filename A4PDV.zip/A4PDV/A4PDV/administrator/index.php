<?php
	session_start();
	require_once dirname(__DIR__).'/model/config.php';
	require_once $url['path'].'/model/class/Connect.class.php';
	require_once $url['path'].'/model/class/Manager.class.php';

	if(isset($_SESSION['user']) and $_SESSION['user']['user_type_user'] == "Administrador" or $_SESSION['user']['user_type_user'] == "Coordenador"){
		include_once $url['path'].'/administrator/content/template.html';
	}else{
		header('location: '.$url['index'].'/administrator/login.php');
	}