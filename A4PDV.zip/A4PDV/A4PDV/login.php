<?php
	require_once 'model/config.php';
	session_start();
	if(isset($_SESSION['user'])){
		header('location: '.$url['index']);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Login - in9PDV </title>
	<?php include_once $url['path'].'/view/content/css.html'; ?>
</head>
<body>
	<br /><br />
	<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">

				<div class="panel panel-default">

					<form method="post" action="<?php echo $url['index']; ?>/controller/controll_access.php?method=login">

					<div class="panel-heading">
						<div class="row">
							<div class="col-md-4">
								<img src="<?php echo $url['index']; ?>/view/images/in9pdv.jpg" class="img-responsive" width="70" height="70" />
							</div>
							<div class="col-md-8">
								<h3><strong>in9PDV</strong></h3>
							</div>
						</div>
					</div>

					<div class="panel-body">
							<div class="form-group">
							<label>Login</label>
							<div class="input-group">
							<div class="input-group-addon"><i class="glyphicon glyphicon-user"></i></div>
							<input type="text" name="user_login" class="form-control" placeholder="login">
							</div>
							</div>

							<div class="form-group">
							<label>Senha</label>
							<div class="input-group">
							<div class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></div>
							<input type="password" name="user_password" class="form-control" placeholder="Senha">
							</div>
							</div>
					</div>

					<div class="panel-footer">
						
						<button class="btn btn-warning"><i class="glyphicon glyphicon-question-sign"></i> Sem Acesso</button>
						<div class="pull-right"><button class="btn btn-primary"><i class="glyphicon glyphicon-log-in"></i> Entrar</button></div>
					</div>

					</form>

				</div>
		</div>
		<div class="col-md-4"></div>
	</div>
</body>
</html>