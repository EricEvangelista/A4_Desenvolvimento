<?php
	session_start();
	//session_destroy();
	require_once 'model/config.php';
	if(isset($_SESSION['user'])){
		include_once 'view/content/template.html';
	}else{
		header('location: '.$url['index'].'/login.php');
	}
	
	
